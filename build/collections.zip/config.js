exports.default = {
  tableName: 'choosy-moms-api-collections'
};
