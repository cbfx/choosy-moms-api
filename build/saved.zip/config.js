exports.default = {
  tableName: 'saved'
};
