module.exports = {
  tableName: 'choosy-moms-api-collections'
};
