exports.default = {
  tableName: 'collections'
};
