exports.default = {
  tableName: 'choosy-moms-api-saved'
};
